<?php

namespace App\Providers;

use App\Providers\ResetPassword;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendOtpVerificationNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Providers\ResetPassword  $event
     * @return void
     */
    public function handle(ResetPassword $event)
    {
       $smsmessage =urlencode("$event->otp IS YOUR OTP TO REGISTER IN WHIZZKART. OTP VALID FOR 60 MINUTES.");
       $sms_url1 = "http://sms.osdigital.in/V2/http-api.php?apikey=Rp03h3MX0zg9VQCS&senderid=Whizkt&number=".$event->mobile."&message=".$smsmessage."&format=json";
       $res=file_get_contents($sms_url1);
       
    }
}
