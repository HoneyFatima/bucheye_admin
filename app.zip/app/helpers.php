<?php

function getCommonStatus(){
        return ['Active','InActive'];
    }
function getBannerType(){
    return ['Top','Bottom','Middle'];
}
function getOrderStatus(){
    return ['Booked','Delivered','Not Delivered','Picked Up','Not Delivered','Delivery Rejected','Vendor Accepted','Vendor Rejected','Delivery Accepted'];
}
function getPaymentStatus(){
    return ['Pending','Paid','Not Paid'];
}
function getPaymentMode(){
    return ['Online','Cash On Delivery'];
}
function getPaymentResponse(){
    return ['Accepted','Not Accepted'];
}

?>
