<?php
namespace App\services;
use App\Models\Category;;
use Illuminate\Http\Request;
class categoryService{


    public function __construct(){
        
    }
    function getCategory($request){
        $data=Category::select('id','parent_id','image','name')->with(['child'=>function($q){
            $q->select('id','parent_id','image','name')->with(['child'=>function($q){
                $q->select('id','parent_id','image','name');
            }]);
        }])->where(['status'=>'Active'])->where(['parent_id'=>0])->get()->toArray();
        $datas=[];
        foreach ($data as $d){
            if(!empty($d['child'])){
                $datas[]=$d;
            }
        }
        return $datas;
       
    }
    

    
}
